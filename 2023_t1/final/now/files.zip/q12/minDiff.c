
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "BSTree.h"

int minDiff(BSTree t, int l) {
    // TODO
    return -1;
}

